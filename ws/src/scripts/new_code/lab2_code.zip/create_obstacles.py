import numpy as np


ob1_x = -0.07
ob1_y = 0.
ob1_z = -0.42
ob2_x = -0.02
ob2_y = 0.22
ob2_z = 0.18

obstacle_transforms = np.array([[[1., 0., 0., ob1_x],
							     [0., 1., 0., ob1_y],
							     [0., 0., 1., ob1_z],
							     [0., 0., 0., 1.	]],

							    [[1., 0., 0., ob2_x*1.1],
							     [0., 1., 0., ob2_y*1.1],
							     [0., 0., 1., ob2_z*1.1],
							     [0., 0., 0., 1.    ]]])

obstacle_dimensions = np.array([[1., 1., 1.],
								[0.14, 0.1, 0.28]])

np.save("npyFiles/L2_HT2Origin_obstacles.npy", obstacle_transforms)
np.save("npyFiles/L2_dim_obstacles.npy", obstacle_dimensions)

#print(obstacle_transforms)
#print(obstacle_dimensions)

#path = np.load("execute_path.npy")

#print(path)