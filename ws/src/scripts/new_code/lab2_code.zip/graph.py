import numpy as np
import random
from sys import exit
from safetyCheck.is_V_safe import EisSafe
from collections import deque


class Vertice:
    def __init__(self, config):
        self.config = np.array(config)
        self.is_visited = False
        self.parent = None
        self.connected_vertice = []
    def euclidean_distance(self, vert_):
        return sum ((vert_.config - self.config)**2)

class Graph:
    def __init__(self):
        self.vertices_graph = []

    def randomSample(self,):
        num_joint = 5
        joint_limit = 0.5*np.pi
        sample = np.random.uniform( low     =   -joint_limit,
                                    high    =   0.9*joint_limit,
                                    size    =   (num_joint,)    )
        res = np.zeros(6)
        res[1:] = sample
        return res

    def connectKnearestVertices(self,query_vertice_):
        # connect vertices if they are close in eculidean dist
        K = 5 ;    bound = 1000**2
        sorted_vertices= sorted(    self.vertices_graph, 
                                    key = query_vertice_.euclidean_distance )
        knearest = []                            
        for i, adjacent_vert_ in enumerate(sorted_vertices[1:]): # ignore query itself 
            if i > K-1: break
            if( query_vertice_.euclidean_distance( adjacent_vert_ ) < bound\
                and EisSafe(query_vertice_.config, adjacent_vert_.config)   ): 

                if not adjacent_vert_ in query_vertice_.connected_vertice:
                    query_vertice_.connected_vertice.append(adjacent_vert_)

                if not query_vertice_ in adjacent_vert_.connected_vertice:
                    adjacent_vert_.connected_vertice.append(query_vertice_)

    def DFS(self,source_vertice_, goal_vertice_):
        '''
        purpose:    this function will traverse config space and return 
                    a viable path of config to the goal if such path exist
                    otherwise return None
        '''

        
        if source_vertice_ is None:
            return None

        queue = deque([source_vertice_])
        if np.array_equal(source_vertice_.config, goal_vertice_.config):
            return source_vertice_.config

        while queue:
            curr = queue.popleft()
            if curr.is_visited == True: continue
            if np.array_equal(curr.config, goal_vertice_.config):
                return self.backtrace(curr) 
            curr.is_visited = True
            for vert in curr.connected_vertice:
                if vert.is_visited is not True:
                    vert.parent = curr
                    queue.append(vert)
        self.exiting()

    def backtrace(self,vertice):
        print "tracing..."
        res = []

        while vertice != None:
            padding = np.zeros(7)
            padding[5] = -0.03
            padding[6] = 0.03
            padding[:5] = vertice.config[1:]
            res.append( padding )
            vertice = vertice.parent

        res.reverse()
        res = np.stack(res, axis= 0 )

        if res is None:
            self.exiting()
        return res

    def exiting(self):
        print "No viable path found, potential issues\n",\
        "(1) all edges blocked by the c_obs \n",\
        "(2) the distance between points are beyond limit bound\n",\
        " try to increase the bound limit in connectknearstVertice\n"\
        " \nchecking accessiblity and departability..."
        print "src has {} edges".format( len(self.vertices_graph[-2].connected_vertice) )
        print "goal has {} edges".format( len(self.vertices_graph[-1].connected_vertice) ) 
        print "exiting..."
        exit()

    def access( self, query_vertice_ ):
        self.vertices_graph.append( query_vertice_ )
        self.connectKnearestVertices(query_vertice_)

    def depart( self, query_vertice_):
        self.vertices_graph.append( query_vertice_ )
        self.connectKnearestVertices(query_vertice_)
